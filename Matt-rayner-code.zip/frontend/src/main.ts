import "./style.css";
import "./strap.css";

import "./leftTab.ts";

